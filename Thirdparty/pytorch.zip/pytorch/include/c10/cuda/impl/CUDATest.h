#pragma once

#include <c10/cuda/CUDAMacros.h>

namespace c10 {
namespace cuda {
namespace impl {

C10_CUDA_API int c10_cuda_test();

}
} // namespace cuda
} // namespace c10
