#pragma once

#include <cstddef>

namespace c10 {

using std::in_place;
using std::in_place_index_t;
using std::in_place_t;
using std::in_place_type_t;

} // namespace c10
