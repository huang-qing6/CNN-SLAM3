#ifndef C10_MACROS_CMAKE_MACROS_H_
#define C10_MACROS_CMAKE_MACROS_H_

// Automatically generated header file for the C10 library.
// Do not include this file directly. Instead, include c10/macros/Macros.h.

#define C10_BUILD_SHARED_LIBS
/* #undef C10_USE_GLOG */
/* #undef C10_USE_GFLAGS */
/* #undef C10_USE_NUMA */
/* #undef C10_USE_MSVC_STATIC_RUNTIME */
/* #undef C10_USE_ROCM_KERNEL_ASSERT */

#endif // C10_MACROS_CMAKE_MACROS_H_
